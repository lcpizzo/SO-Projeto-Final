var searchData=
[
  ['normalize_712',['Normalize',['../classraylib_1_1_color.html#a70c0b9f2b6bc92724df1c87553cbca32',1,'raylib::Color::Normalize()'],['../classraylib_1_1_vector2.html#aee50557d8a60c2633de106f66b3d6cd5',1,'raylib::Vector2::Normalize()']]]
];
