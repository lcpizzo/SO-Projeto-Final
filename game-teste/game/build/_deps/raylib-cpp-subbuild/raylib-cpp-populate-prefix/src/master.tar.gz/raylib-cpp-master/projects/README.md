# raylib-cpp Projects

The following are some base templates to use when making new raylib-cpp projects.

- [CMake](CMake): Uses `cmake` to build the project files
- [Make](Make): A project template that uses `make` to compile the project
- [VSCode](VSCode): A VSCode template that uses `make` along with the base configurations
