# raylib-cpp CMake Example Project

Use this template to build a [raylib-cpp](https://github.com/RobLoach/raylib-cpp) project using CMake.

## Build

```
mkdir build
cd build
cmake ..
make
```

## Run

```
./raylib-cpp-example
```
